# Results


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from cyborgdb.openapi_client.models.results import Results

# TODO update the JSON string below
json = "{}"
# create an instance of Results from a JSON string
results_instance = Results.from_json(json)
# print the JSON string representation of the object
print(Results.to_json())

# convert the object into a dict
results_dict = results_instance.to_dict()
# create an instance of Results from a dict
results_from_dict = Results.from_dict(results_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


