# ValidationErrorLocInner


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from cyborgdb.openapi_client.models.validation_error_loc_inner import ValidationErrorLocInner

# TODO update the JSON string below
json = "{}"
# create an instance of ValidationErrorLocInner from a JSON string
validation_error_loc_inner_instance = ValidationErrorLocInner.from_json(json)
# print the JSON string representation of the object
print(ValidationErrorLocInner.to_json())

# convert the object into a dict
validation_error_loc_inner_dict = validation_error_loc_inner_instance.to_dict()
# create an instance of ValidationErrorLocInner from a dict
validation_error_loc_inner_from_dict = ValidationErrorLocInner.from_dict(validation_error_loc_inner_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


